#include "headers.h"

int main(int argc, char * argv[])
{
    //initClk();
    printf("%c\n",*argv[0]);


    //TODO implement the scheduler :)
    //upon termination release the clock resources.
    while(1){}
    //destroyClk(true);
}

